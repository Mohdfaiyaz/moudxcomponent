import styled, { css } from 'styled-components';

export default styled.div(() => {
  return css`
    margin: 0;
    padding: 12px;

    .employee-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
      gap: 20px;
    }

    .employee-card {
      background: #ffffff;
      border-radius: 16px;
      padding: 18px;
      border: 1px solid #e5e7eb;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
      transition: all 0.25s ease;
      cursor: pointer;
      overflow: hidden;
      position: relative;
    }

    .employee-card:hover {
      transform: translateY(-4px);
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.12);
    }

    .employee-card::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 4px;
      background: #0f62fe;
    }

    .card-header {
      display: flex;
      align-items: center;
      gap: 12px;
      margin-bottom: 16px;
    }

    .avatar {
      width: 48px;
      height: 48px;
      border-radius: 50%;
      background: #0f62fe;
      color: #fff;
      font-weight: 600;
      font-size: 16px;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }

    .employee-name {
      font-size: 18px;
      font-weight: 600;
      color: #1f2937;
      margin: 0;
    }

    .employee-type {
      display: inline-block;
      margin-top: 4px;
      padding: 4px 10px;
      border-radius: 20px;
      background: #e8f5e9;
      color: #2e7d32;
      font-size: 12px;
      font-weight: 600;
    }

    .employee-details {
      font-size: 13px;
      color: #4b5563;
      line-height: 1.8;
    }

    .employee-details div {
      margin-bottom: 6px;
    }

    .skills-container {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
      margin-top: 14px;
    }

    .skill-tag {
      background: #eef4ff;
      color: #0f62fe;
      border: 1px solid #d6e4ff;
      border-radius: 20px;
      padding: 4px 10px;
      font-size: 11px;
      font-weight: 500;
    }
  `;
});
